import React from 'react';

export default function Ex203() {
    document.title = "툴팁 달기"
    return (
      <div>
        <h1 title="h1태그로 작성하였습니다.">1장 홈페이지</h1>
        <h2 title="h2태그로 작성하였습니다.">1절 HTML 언어</h2>
      </div>
    )
}