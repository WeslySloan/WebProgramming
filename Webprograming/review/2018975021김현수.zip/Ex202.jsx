import React from 'react';

export default function Ex202() {
    document.title = "문단 제목 달기"
    return (
      <div>
        <h1>1장 홈페이지 만들기</h1>
        <h2>1절 HTML 언어</h2>
        <h3>1. 웹</h3>
        <h4>1.1 인터넷</h4>
        <h5>1.1.1 네트워크</h5>
        <h6>1.1.1.1. 통신</h6>
      </div>
    )
}
