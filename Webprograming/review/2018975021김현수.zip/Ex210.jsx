import React from 'react';

export default function Ex203() {
    document.title = "&lt;div&gt;블록과  &lt;span&gt;인라인"
    return (
    <body>
        <h3>사랑</h3>
        <hr />
        <div style={{backgroundColor:"skyblue", padding:"20px"}}>
        내가 사람의 방언과 천사의 말을 할지라도
        <span style={{ color: "red" }}> 사랑</span>이 없으면 소리 나는 구리와 울리는 꽹과리가 되고,
        <span style={{ color: "red" }}> 사랑</span>이 없으면 아무 것도 아니라.
        </div>
        <p>
            ~우리 서로 사랑하며 살아요~
        </p>
    </body>
    )
}